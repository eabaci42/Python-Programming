# Hello :) -> Hello 🙂
# Goodbye :( -> Goodbye 🙁
# Hello :) Goodbye :( -> Hello 🙂 Goodbye 🙁
faces = input().replace(":)","🙂")
faces = faces.replace(":(","🙁")
print(faces)
